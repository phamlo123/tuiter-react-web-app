import React from "react";
import ReduxExamples from "./redux-examples";

const Assignment7 = () => {
 return(
   <>
     <h1>Assignment 7</h1>
     <ReduxExamples/>
   </>
 );
};
export default Assignment7;