import React from "react"

function WelcometoFSD() {
    <p>
        welcome to whatev
    </p>
}
export default WelcometoFSD;

